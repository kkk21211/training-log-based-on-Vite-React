import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import "./Sidebar.css";

const Sidebar = () => {
  const location = useLocation();
  const email = localStorage.getItem("currentUser");
  const username = email ? email.split("@")[0] : "Guest";
  const [isOpen, setIsOpen] = useState(false);

  const isActive = (path) => location.pathname === path;

  const handleLogout = () => {
    localStorage.removeItem("currentUser");
    window.location.href = "/";
  };

  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };

  return (
    <>
      <button className="menu-toggle" onClick={toggleSidebar}>
        <span className="menu-icon"></span>
      </button>
      <div className={`sidebar ${isOpen ? 'open' : ''}`}>
        <div className="sidebar-header">
          <span className="sidebar-title">Menu</span>
          <button className="close-btn" onClick={toggleSidebar}>×</button>
        </div>
        <Link to="/plan" className={isActive("/plan") ? "active" : ""} onClick={toggleSidebar}>Plan</Link>
        <Link to="/todo" className={isActive("/todo") ? "active" : ""} onClick={toggleSidebar}>Todo</Link>
        <Link to="/log" className={isActive("/log") ? "active" : ""} onClick={toggleSidebar}>Log</Link>
        <Link to="/health" className={isActive("/health") ? "active" : ""} onClick={toggleSidebar}>Health</Link>
        <Link to="/diet" className={isActive("/diet") ? "active" : ""} onClick={toggleSidebar}>Diet</Link>
        <Link to="/stats" className={isActive("/stats") ? "active" : ""} onClick={toggleSidebar}>Stats</Link>

        <div className="sidebar-footer">
          <div className="sidebar-user">{username}</div>
          <button className="logout-btn" onClick={handleLogout}>Logout</button>
        </div>
      </div>
      {isOpen && <div className="sidebar-overlay" onClick={toggleSidebar}></div>}
    </>
  );
};

export default Sidebar;
