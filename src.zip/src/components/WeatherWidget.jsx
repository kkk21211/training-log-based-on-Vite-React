import React, { useEffect, useState } from "react";
import "./WeatherWidget.css";

const WeatherWidget = () => {
  const [temp, setTemp] = useState(null);
  const [condition, setCondition] = useState("");

  useEffect(() => {
    fetch("https://api.open-meteo.com/v1/forecast?latitude=42.36&longitude=-71.06&current_weather=true")
      .then(res => res.json())
      .then(data => {
        setTemp(data.current_weather.temperature);
        setCondition(data.current_weather.weathercode); 
      })
      .catch(() => {
        setTemp("N/A");
        setCondition("cloud");
      });
  }, []);

  const getIcon = () => {
    if (condition === 0) return "☀️";     
    if (condition < 4) return "🌤️";          
    if (condition < 7) return "☁️";          
    if (condition < 20) return "🌧️";         
    return "🌡️";
  };

  return (
    <div className="weather-widget">
      {getIcon()} Boston: {temp}°C
    </div>
  );
};

export default WeatherWidget;
