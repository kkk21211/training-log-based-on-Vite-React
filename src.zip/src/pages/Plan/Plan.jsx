import React, { useState, useEffect } from "react";
import Sidebar from "../../components/Sidebar/Sidebar";
import "./Plan.css";
import toastr from "toastr";
import "/node_modules/toastr/build/toastr.min.css";
import WeatherWidget from "../../components/WeatherWidget";

const defaultTrainingTypes = [
  { type: "Running", icon: "/assets/running.jpeg" },
  { type: "Swimming", icon: "/assets/swimming.png" },
  { type: "Fitness", icon: "/assets/fitness.png" },
  { type: "Yoga", icon: "/assets/yoga.png" },
  { type: "Boxing", icon: "/assets/boxing.png" },
  { type: "Squat", icon: "/assets/squat.png" },
  { type: "Pull-up", icon: "/assets/pullup.png" },
  { type: "Jumping Jack", icon: "/assets/jumping_jack.png" },
  { type: "Jump Rope", icon: "/assets/jump_rope.png" }
];

const Plan = () => {
  const email = localStorage.getItem("currentUser");
  if (!email) {
    window.location.href = "/";
    return null;
  }

  const [formData, setFormData] = useState({
    type: "",
    duration: "",
    weight: "",
    sets: "",
    datetime: "",
    notes: ""
  });

  const [trainingTypes, setTrainingTypes] = useState(defaultTrainingTypes);
  const [showModal, setShowModal] = useState(false);
  const [newType, setNewType] = useState("");
  const [quote, setQuote] = useState(null);

  useEffect(() => {
    fetch("https://api.allorigins.win/get?url=" + encodeURIComponent("https://zenquotes.io/api/random"))
      .then((res) => res.json())
      .then((data) => {
        const parsed = JSON.parse(data.contents);
        const result = parsed[0];
        if (result.a !== "Unknown") {
          setQuote({ content: result.q, author: result.a });
        } else {
          setQuote({ content: result.q });
        }
      })
      .catch(() => {
        setQuote({ content: "Push yourself, because no one else is going to do it for you." });
      });
  }, []);

  const handleSelectType = (type) => {
    setFormData({ ...formData, type });
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleTypeDropdown = (e) => {
    const value = e.target.value;
    if (value === "add") {
      setShowModal(true);
    } else {
      setFormData({ ...formData, type: value });
    }
  };

  const handleAddCustomType = () => {
    if (newType.trim() !== "") {
      const newOption = { type: newType, icon: "/assets/running.jpeg" }; 
      setTrainingTypes([...trainingTypes, newOption]);
      setFormData({ ...formData, type: newType });
      setNewType("");
      setShowModal(false);
      toastr.success("Custom type added successfully");
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.type || !formData.duration || !formData.sets || !formData.datetime) {
      toastr.error("Please fill in all required fields: Type, Duration, Sets, and Planned Time.");
      return;
    }
    const todos = JSON.parse(localStorage.getItem(`plannedTodos__${email}`) || "[]");
    todos.push({ ...formData, id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}` });
    localStorage.setItem(`plannedTodos__${email}`, JSON.stringify(todos));
    toastr.success("Saved successfully");
    setFormData({
      type: "",
      duration: "",
      weight: "",
      sets: "",
      datetime: "",
      notes: ""
    });
  };

  return (
    <div className="app-container">
      <Sidebar />
      <WeatherWidget />
      <div className="page-content plan-layout">
        <h2>Add Plan</h2>
        <div className="plan-content-wrapper">
          <form className="plan-form" onSubmit={handleSubmit}>
            <label><span className="label-inline required">Type:</span>
              <select value={formData.type} onChange={handleTypeDropdown} className="full-width" required>
                <option value="">Select Type</option>
                {trainingTypes.map(({ type }) => (
                  <option key={type} value={type}>{type}</option>
                ))}
                <option value="add">Add New</option>
              </select>
            </label>

            <label><span className="label-inline required">Duration (minutes):</span>
              <input name="duration" autoComplete="off" value={formData.duration} onChange={handleChange} required className="full-width" />
            </label>

            <label><span className="label-inline">Intensity (kg):</span>
              <input name="weight" autoComplete="off" value={formData.weight} onChange={handleChange} className="full-width" />
            </label>

            <label><span className="label-inline required">Sets:</span>
              <input name="sets" autoComplete="off" value={formData.sets} onChange={handleChange} required className="full-width" />
            </label>

            <label><span className="label-inline required">Planned Time:</span>
              <input type="datetime-local" autoComplete="off" name="datetime" value={formData.datetime} onChange={handleChange} required className="full-width" />
            </label>

            <label><span className="label-inline">Notes:</span>
              <textarea name="notes" autoComplete="off" value={formData.notes} onChange={handleChange} className="full-width" />
            </label>

            <button type="submit">Submit</button>
          </form>

          <div className="icon-grid">
            {trainingTypes.map(({ type, icon }) => (
              <img
                key={type}
                src={icon}
                alt={type}
                onClick={() => handleSelectType(type)}
                className={formData.type === type ? "selected-icon" : ""}
              />
            ))}

            {quote && (
              <div className="quote-box plan-quote">
                <h3 className="quote-title">Today's Motivation</h3>
                <p className="quote-text">{quote.content}</p>
                {quote.author && <p className="quote-author">— {quote.author}</p>}
              </div>
            )}
          </div>
        </div>
      </div>

      {showModal && (
        <div className="modal-overlay">
          <div className="modal">
            <h3>Add Custom Type</h3>
            <input
              type="text"
              value={newType}
              onChange={(e) => setNewType(e.target.value)}
              placeholder="Enter custom type"
              className="full-width"
            />
            <div className="modal-actions">
              <button onClick={handleAddCustomType}>Confirm</button>
              <button onClick={() => setShowModal(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Plan;
