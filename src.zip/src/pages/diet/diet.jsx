import React, { useState, useEffect } from "react";
import Sidebar from "../../components/Sidebar/Sidebar";
import "./diet.css";
import toastr from "toastr";
import "toastr/build/toastr.min.css";
import WeatherWidget from "../../components/WeatherWidget";

const Diet = () => {
  const email = localStorage.getItem("currentUser");
  if (!email) {
    window.location.href = "/";
    return null;
  }

  const [foods, setFoods] = useState([{ name: "", calories: 0, quantity: 1, unit: "", meal: "Breakfast" }]);
  const [total, setTotal] = useState(0);
  const [showTotal, setShowTotal] = useState(false);
  const [recommendations, setRecommendations] = useState([]);
  const [selectedGoal, setSelectedGoal] = useState("Muscle Gain");
  const [selectedMeal, setSelectedMeal] = useState("Breakfast");
  const [calorieMap, setCalorieMap] = useState({});
  const [unitMap, setUnitMap] = useState({});
  const [latestHealth, setLatestHealth] = useState(null);
  const [suggestedGoal, setSuggestedGoal] = useState(null);

  useEffect(() => {
    fetch("/data/diet_recommendations.json")
      .then(res => res.json())
      .then(data => setRecommendations(data))
      .catch(err => console.error("Failed to load recommendations", err));

    fetch("/data/food_calories.json")
      .then(res => res.json())
      .then(data => {
        const cMap = {}, uMap = {};
        data.forEach(f => {
          cMap[f.name.toLowerCase()] = f.calories;
          uMap[f.name.toLowerCase()] = f.unit.replace(/^per\s*/i, "").trim();
        });
        setCalorieMap(cMap);
        setUnitMap(uMap);
      })
      .catch(err => console.error("Failed to load food data", err));

    const stored = JSON.parse(localStorage.getItem(`healthRecords__${email}`) || "[]").sort((a, b) => b.date.localeCompare(a.date));
    if (stored.length > 0) {
      setLatestHealth(stored[0]);
      const bmi = parseFloat(stored[0].bmi);
      const fat = parseFloat(stored[0].fat.replace("%", ""));
      let matched = null;

      if (bmi < 18.5) matched = "Muscle Gain";
      else if (bmi >= 18.5 && bmi <= 24.9 && fat <= 20) matched = "Maintenance";
      else if (bmi >= 25 || fat >= 25) matched = "Fat Loss";
      else matched = "Maintenance";

      setSuggestedGoal(matched);
    }
  }, []);

  const handleInputChange = (value, index) => {
    const updated = [...foods];
    updated[index].name = value;
    const key = value.toLowerCase();
    updated[index].calories = calorieMap[key] || 0;
    updated[index].unit = unitMap[key] || "";
    setFoods(updated);
    if (updated[index].calories >= 250) {
      toastr.warning("Too many calories, are you sure you want to add this?");
    }
  };

  const handleQuantityChange = (value, index) => {
    const updated = [...foods];
    updated[index].quantity = Number(value);
    setFoods(updated);
  };

  const removeFood = (index) => {
    if (foods.length === 1) return toastr.error("At least one food item must be present.");
    const updated = [...foods];
    updated.splice(index, 1);
    setFoods(updated);
  };

  const addFood = () => {
    setFoods([...foods, { name: "", calories: 0, quantity: 1, unit: "", meal: selectedMeal }]);
  };

  const calculateTotal = () => {
    const kcal = foods.filter(f => f.meal === selectedMeal)
      .reduce((sum, f) => sum + (f.calories || 0) * (f.quantity || 1), 0);
    setTotal(kcal);
    setShowTotal(true);
  };

  const currentGoal = recommendations.find(r => r.goal === selectedGoal);
  const currentMealGoal = currentGoal ? currentGoal[selectedMeal.toLowerCase()] : null;

  return (
    <div className="app-container">
      <Sidebar />
      <WeatherWidget />
      <div className="page-content plan-layout" style={{ display: "flex", gap: "2rem" }}>
        <div style={{ flex: 1 }}>
          <h2>Diet & Nutrition</h2>
          <div className="plan-form" style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
            <div style={{ display: "flex", gap: "10px" }}>
              <select value={selectedGoal} onChange={e => setSelectedGoal(e.target.value)}>
                {recommendations.map((r, i) => (
                  <option key={i} value={r.goal}>{r.goal}</option>
                ))}
              </select>
              <select value={selectedMeal} onChange={e => setSelectedMeal(e.target.value)}>
                <option value="Breakfast">Breakfast</option>
                <option value="Lunch">Lunch</option>
                <option value="Dinner">Dinner</option>
              </select>
            </div>

            {foods.map((food, i) => (
              <div key={i}>
                <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                  <input placeholder={`Food #${i + 1}`} value={food.name}
                    onChange={(e) => handleInputChange(e.target.value, i)} style={{ flex: 2 }} />
                  <input type="number" min="1" placeholder={food.unit || "Unit"} value={food.quantity}
                    onChange={(e) => handleQuantityChange(e.target.value, i)} style={{ flex: 1 }} />
                  <span style={{ flex: 1 }}>
                    {food.calories ? `${food.calories * food.quantity} kcal` : ""}
                  </span>
                  <button onClick={() => removeFood(i)} style={{ padding: "2px 6px", fontSize: "0.75rem", marginLeft: "auto" }}
                    disabled={foods.length === 1}>Remove</button>
                </div>
              </div>
            ))}

            <div style={{ display: "flex", gap: "10px" }}>
              <button onClick={addFood}>+ Add Food</button>
              <button onClick={calculateTotal}>Finish</button>
            </div>

            {showTotal && (
              <div style={{ marginTop: "1rem", fontSize: "1.1rem" }}>
                <strong>Total:</strong> {total} kcal
                {currentMealGoal && (
                  <span style={{ marginLeft: "10px", color: total > currentMealGoal ? "red" : "orange" }}>
                    ({total > currentMealGoal ? "+" : "-"}{Math.abs(total - currentMealGoal)} kcal)
                  </span>
                )}
              </div>
            )}
          </div>
        </div>

        <div style={{ flex: 1, background: "#f4faff", padding: "1.5rem", borderRadius: "12px" }}>
          <h3 style={{ marginBottom: "1rem" }}>Recommended Calorie Intakes</h3>
          <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
            {recommendations.map((r, i) => (
              <details key={i} style={{ padding: "8px", border: "1px solid #ccc", borderRadius: "8px", background: "white" }}>
                <summary style={{ fontWeight: "bold" }}>{r.goal} ({r.target})</summary>
                <ul style={{ marginTop: "0.5rem" }}>
                  <li><strong>Breakfast:</strong> {r.breakfast} kcal</li>
                  <li><strong>Lunch:</strong> {r.lunch} kcal</li>
                  <li><strong>Dinner:</strong> {r.dinner} kcal</li>
                </ul>
              </details>
            ))}

            {suggestedGoal && (
              <details open style={{
                padding: "10px", marginTop: "1rem",
                backgroundColor: "#fff6e5", border: "2px solid #ffa726",
                borderRadius: "10px", fontWeight: "bold"
              }}>
                <summary>🎯 Recommendation</summary>
                <div style={{ marginTop: "8px", fontWeight: "normal" }}>
                  Based on your latest BMI and fat, we suggest: &nbsp;
                  <strong style={{ color: "#e65100" }}>{suggestedGoal}</strong>
                </div>
              </details>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Diet;
