import React, { useEffect, useState } from "react";
import Sidebar from "../../components/Sidebar/Sidebar";
import "./Log.css";
import WeatherWidget from "../../components/WeatherWidget";

const Log = () => {
  const email = localStorage.getItem("currentUser");
  if (!email) {
    window.location.href = "/";
    return null;
  }

  const [logs, setLogs] = useState([]);

  useEffect(() => {
    const stored = JSON.parse(localStorage.getItem(`completedTodos__${email}`) || "[]");
    setLogs(stored);
  }, []);

  return (
    <div className="app-container">
      <Sidebar />
      <WeatherWidget />
      <div className="page-content plan-layout">
        <h2 className="center">Training Log</h2>
        <div className="todo-table-wrapper">
          <table className="todo-table">
            <thead>
              <tr>
                <th>Type</th>
                <th>Duration</th>
                <th>Weight</th>
                <th>Sets</th>
                <th>Time</th>
                <th>Notes</th>
              </tr>
            </thead>
            <tbody>
              {logs.map((log, index) => (
                <tr key={log.id}>
                  <td>{log.type}</td>
                  <td>{log.duration}</td>
                  <td>{log.weight}</td>
                  <td>{log.sets}</td>
                  <td>{log.datetime}</td>
                  <td>{log.notes}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Log;
