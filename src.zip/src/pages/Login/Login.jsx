import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import "./Login.css";
import toastr from "toastr";
import "toastr/build/toastr.min.css";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();
    const users = JSON.parse(localStorage.getItem("users") || "{}");

    if (!users[email]) {
      toastr.error("Account not found. Please register.");
      return;
    }

    const storedPassword = atob(users[email].password);
    if (password !== storedPassword) {
      toastr.error("Incorrect password.");
      return;
    }

    localStorage.setItem("currentUser", email);

    const keys = ["plannedTodos", "completedTodos", "healthRecords"];
    keys.forEach((k) => {
      const fullKey = `${k}__${email}`;
      if (!localStorage.getItem(fullKey)) {
        localStorage.setItem(fullKey, JSON.stringify([]));
      }
    });

    toastr.success("Logged in successfully!");
    navigate("/plan"); 
  };

  return (
    <div id="login-wrapper">
      <form id="login-form" autoComplete="off" onSubmit={handleLogin}>
        <h2 className="login-title">Welcome to training log</h2>

        <div className="form-group" id="login-email-group">
          <label htmlFor="login-email">Email</label>
          <input
            type="email"
            id="login-email"
            name="email"
            autoComplete="off"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>

        <div className="form-group" id="login-password-group">
          <label htmlFor="login-password">Password</label>
          <input
            type="password"
            id="login-password"
            name="password"
            autoComplete="off"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>

        <button className="login-button" id="login-submit" type="submit">Login</button>

        <div className="login-links">
          <Link to="/register" className="link">Don't have an account? Register</Link>
          <a href="#" className="link">Forgot password?</a>
        </div>
      </form>
    </div>
  );
};

export default Login;
