import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Register.css";
import toastr from "toastr";
import "toastr/build/toastr.min.css";

const Register = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleRegister = (e) => {
    e.preventDefault();

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      toastr.error("Please enter a valid email address.");
      return;
    }

    const users = JSON.parse(localStorage.getItem("users") || "{}");

    if (users[email]) {
      toastr.error("This email is already registered.");
      return;
    }

    users[email] = {
      password: btoa(password),
      todos: [],
      logs: [],
      health: []
    };

    localStorage.setItem("users", JSON.stringify(users));
    localStorage.setItem("currentUser", email);

    const keys = ["plannedTodos", "completedTodos", "healthRecords"];
    keys.forEach((k) => {
      const fullKey = `${k}__${email}`;
      if (!localStorage.getItem(fullKey)) {
        localStorage.setItem(fullKey, JSON.stringify([]));
      }
    });

    toastr.success("Registered successfully!");
    navigate("/");
  };

  return (
    <div id="register-wrapper">
      <form id="register-form" autoComplete="off" onSubmit={handleRegister}>
        <h2 className="register-title">Create Account</h2>

        <div className="form-group" id="email-group">
          <label htmlFor="email">Email Address</label>
          <input
            type="email"
            id="email"
            name="email"
            autoComplete="off"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>

        <div className="form-group" id="password-group">
          <label htmlFor="password">Create Password</label>
          <input
            type="password"
            id="password"
            name="password"
            autoComplete="off"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>

        <button id="register-submit" className="register-button" type="submit">Register</button>
      </form>
    </div>
  );
};

export default Register;
