import React, { useEffect, useState } from "react";
import Sidebar from "../../components/Sidebar/Sidebar";
import WeatherWidget from "../../components/WeatherWidget";
import {
  LineChart, Line,
  PieChart, Pie, Cell,
  CartesianGrid, XAxis, YAxis, Tooltip, Legend,
  ResponsiveContainer
} from "recharts";

const Stats = () => {
  const email = localStorage.getItem("currentUser");
  if (!email) {
    window.location.href = "/";
    return null;
  }

  const [todos, setTodos] = useState([]);
  const [health, setHealth] = useState([]);
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");

  useEffect(() => {
    const todoData = JSON.parse(localStorage.getItem(`completedTodos__${email}`) || "[]");
    const healthData = JSON.parse(localStorage.getItem(`healthRecords__${email}`) || "[]");
    setTodos(todoData);
    setHealth(healthData);
  }, []);

  const filterByDate = () => {
    const start = startDate ? new Date(startDate) : null;
    const end = endDate ? new Date(endDate) : null;

    const filteredTodos = todos.filter(item => {
      const d = new Date(item.completedAt || item.datetime);
      return (!start || d >= start) && (!end || d <= end);
    });

    const filteredHealth = health.filter(item => {
      const d = new Date(item.date);
      return (!start || d >= start) && (!end || d <= end);
    });

    setTodos(filteredTodos);
    setHealth(filteredHealth);
  };

  const pieColors = ["#ff6384", "#36a2eb", "#ffcd56", "#4bc0c0", "#9966ff"];

  const pieData = () => {
    const counts = {};
    todos.forEach(t => {
      const type = t.type || "Other";
      counts[type] = (counts[type] || 0) + 1;
    });
    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  };

  const workoutDurationData = () => {
    const map = {};
    todos.forEach(t => {
      const date = (t.completedAt || t.datetime || "").slice(0, 10);
      if (date) {
        map[date] = (map[date] || 0) + Number(t.duration || 0);
      }
    });
    const dates = Object.keys(map).sort();
    return dates.map(date => ({ date, duration: map[date] }));
  };

  const healthTrendData = (key) => {
    return [...health]
      .sort((a, b) => new Date(a.date) - new Date(b.date))
      .map(h => ({ date: h.date?.slice(0, 10), value: parseFloat(h[key] || 0) }));
  };

  return (
    <div className="app-container">
      <Sidebar />
      <WeatherWidget />
      <div className="page-content plan-layout">
        <h2>Statistics</h2>
        <div className="filters">
          <label>Start: <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} /></label>
          <label>End: <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} /></label>
          <button onClick={filterByDate}>Filter</button>
        </div>

        <div className="charts-grid" style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: "2rem",
          gridTemplateRows: "repeat(2, auto)"
        }}>
          <div className="chart-card">
            <h4>Workout Type Distribution</h4>
            <ResponsiveContainer width="100%" height={240}>
              <PieChart>
                <Pie data={pieData()} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80}>
                  {pieData().map((_, index) => (
                    <Cell key={index} fill={pieColors[index % pieColors.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="chart-card">
            <h4>Workout Duration Over Time</h4>
            <ResponsiveContainer width="100%" height={240}>
              <LineChart data={workoutDurationData()}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="duration" stroke="#8884d8" />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="chart-card">
            <h4>Weight Trend</h4>
            <ResponsiveContainer width="100%" height={240}>
              <LineChart data={healthTrendData("weight")}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="value" stroke="green" />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="chart-card">
            <h4>Body Fat Trend</h4>
            <ResponsiveContainer width="100%" height={240}>
              <LineChart data={healthTrendData("fat")}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="value" stroke="red" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Stats;
