import React, { useState, useEffect } from "react";
import Sidebar from "../../components/Sidebar/Sidebar";
import "./Health.css";
import toastr from "toastr";
import "toastr/build/toastr.min.css";
import WeatherWidget from "../../components/WeatherWidget";

const Health = () => {
  const email = localStorage.getItem("currentUser");
  if (!email) {
    window.location.href = "/";
    return null;
  }

  const [record, setRecord] = useState({
    date: "",
    height: "",
    weight: "",
    age: "",
    gender: "male",
    bmi: "",
    fat: "",
    sleep: "Good",
    diet: "Healthy"
  });
  const [history, setHistory] = useState([]);
  const [filter, setFilter] = useState({ start: "", end: "" });
  const [editingIndex, setEditingIndex] = useState(null);
  const [showHistory, setShowHistory] = useState(false);
  const [bmiRange, setBmiRange] = useState("");
  const [bmiStatus, setBmiStatus] = useState("");

  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem(`healthRecords__${email}`) || "[]");
    setHistory(saved);
  }, []);

  const getAgeRange = (age) => {
    const a = parseInt(age);
    if (a <= 24) return "18-24";
    if (a <= 34) return "25-34";
    if (a <= 44) return "35-44";
    if (a <= 54) return "45-54";
    if (a <= 64) return "55-64";
    return "65+";
  };

  const fetchBmiRange = async (age, gender, bmi) => {
    try {
      const res = await fetch("/data/bmi_reference.json");
      const data = await res.json();
      const ageRange = getAgeRange(age);
      const match = data.find((item) => item.gender === gender && item.ageRange === ageRange);
      if (match) {
        setBmiRange(`${match.bmiMin} - ${match.bmiMax}`);
        if (bmi < match.bmiMin) setBmiStatus("Underweight");
        else if (bmi > match.bmiMax) setBmiStatus("Overweight");
        else setBmiStatus("Normal");
      } else {
        setBmiRange("");
        setBmiStatus("");
      }
    } catch (error) {
      console.error("Failed to fetch BMI range", error);
      setBmiRange("");
      setBmiStatus("");
    }
  };

  const calculateMetrics = (height, weight, age, gender) => {
    const h = parseFloat(height);
    const w = parseFloat(weight);
    if (!h || !w || !age) return { bmi: "", fat: "" };
    const hm = h / 100;
    const bmi = w / (hm * hm);
    const fat = gender === "male"
      ? 1.2 * bmi + 0.23 * age - 16.2
      : 1.2 * bmi + 0.23 * age - 5.4;
    fetchBmiRange(age, gender, bmi);
    return {
      bmi: bmi.toFixed(2),
      fat: fat.toFixed(1) + "%"
    };
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    const updated = { ...record, [name]: value };
    if (["height", "weight", "age", "gender"].includes(name)) {
      const { bmi, fat } = calculateMetrics(
        name === "height" ? value : updated.height,
        name === "weight" ? value : updated.weight,
        name === "age" ? value : updated.age,
        name === "gender" ? value : updated.gender
      );
      updated.bmi = bmi;
      updated.fat = fat;
    }
    setRecord(updated);
  };

  const handleEditField = (index, field, value) => {
    const newHistory = [...history];
    newHistory[index] = { ...newHistory[index], [field]: value };
    if (["height", "weight", "age", "gender"].includes(field)) {
      const { bmi, fat } = calculateMetrics(
        field === "height" ? value : newHistory[index].height,
        field === "weight" ? value : newHistory[index].weight,
        field === "age" ? value : newHistory[index].age,
        field === "gender" ? value : newHistory[index].gender
      );
      newHistory[index].bmi = bmi;
      newHistory[index].fat = fat;
    }
    setHistory(newHistory);
    localStorage.setItem(`healthRecords__${email}`, JSON.stringify(newHistory));
    toastr.success("Record updated");
  };

  const saveRecord = () => {
    let newHistory;
    if (editingIndex !== null) {
      newHistory = [...history];
      newHistory[editingIndex] = record;
      setEditingIndex(null);
    } else {
      newHistory = [...history, record];
    }
    setHistory(newHistory);
    localStorage.setItem(`healthRecords__${email}`, JSON.stringify(newHistory));
    toastr.success("Record saved");
    setRecord({
      date: "",
      height: "",
      weight: "",
      age: "",
      gender: "male",
      bmi: "",
      fat: "",
      sleep: "Good",
      diet: "Healthy"
    });
    setBmiRange("");
    setBmiStatus("");
  };

  const deleteRecord = (i) => {
    const updated = history.filter((_, idx) => idx !== i);
    setHistory(updated);
    localStorage.setItem(`healthRecords__${email}`, JSON.stringify(updated));
    toastr.info("Record deleted");
  };

  const filteredHistory = history
    .filter((h) => {
      return (!filter.start || h.date >= filter.start) && (!filter.end || h.date <= filter.end);
    })
    .sort((a, b) => new Date(b.date) - new Date(a.date));

  return (
    <div className="app-container">
      <Sidebar />
      <WeatherWidget />
      <div className="page-content plan-layout">
        <div className="health-form-wrapper">
          <h2 className="center" id="healthTitle">Health Records</h2>
          <form className="plan-form" autoComplete="off">
            <label>Date: <input id="inputDate" name="date" type="date" value={record.date} onChange={handleChange} /></label>
            <label>Height (cm): <input id="inputHeight" name="height" value={record.height} onChange={handleChange} /></label>
            <label>Weight (kg): <input id="inputWeight" name="weight" value={record.weight} onChange={handleChange} /></label>
            <label>Age: <input id="inputAge" name="age" value={record.age} onChange={handleChange} /></label>
            <label>Gender:
              <select id="selectGender" name="gender" value={record.gender} onChange={handleChange}>
                <option value="male">Male</option>
                <option value="female">Female</option>
              </select>
            </label>
            <label>
              BMI:
              <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                <input id="bmiDisplay" value={record.bmi} readOnly style={{ width: "100px" }} />
                <span>Recommand：{bmiRange} {bmiStatus && `(${bmiStatus})`}</span>
              </div>
            </label>
            <label>Fat %: <input id="fatDisplay" value={record.fat} readOnly /></label>
            <div style={{ display: "flex", gap: "10px" }}>
              <button id="saveHealthBtn" type="button" className="save-btn" onClick={saveRecord}>Save Record</button>
              <button type="button" onClick={() => setShowHistory(!showHistory)}>
                {showHistory ? "Hide History" : "Show History"}
              </button>
            </div>
          </form>
        </div>

        {showHistory && (
          <div className="health-history-wrapper">
            <div className="filters">
              <label>Start Date: <input type="date" value={filter.start} onChange={(e) => setFilter({ ...filter, start: e.target.value })} /></label>
              <label>End Date: <input type="date" value={filter.end} onChange={(e) => setFilter({ ...filter, end: e.target.value })} /></label>
            </div>
            <div className="todo-table-wrapper" style={{ maxHeight: "400px", overflowY: "auto" }}>
              <table className="todo-table">
                <thead>
                  <tr>
                    <th>Date</th><th>Height</th><th>Weight</th><th>BMI</th><th>Fat</th><th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredHistory.map((r, i) => (
                    <tr key={i}>
                      {editingIndex === i ? (
                        <>
                          <td><input type="date" value={r.date} onChange={(e) => handleEditField(i, "date", e.target.value)} /></td>
                          <td><input value={r.height} onChange={(e) => handleEditField(i, "height", e.target.value)} /></td>
                          <td><input value={r.weight} onChange={(e) => handleEditField(i, "weight", e.target.value)} /></td>
                          <td><input value={r.bmi} readOnly /></td>
                          <td><input value={r.fat} readOnly /></td>
                          <td>
                            <button onClick={() => setEditingIndex(null)}>Save</button>
                            <button onClick={() => deleteRecord(i)}>Delete</button>
                          </td>
                        </>
                      ) : (
                        <>
                          <td>{r.date}</td>
                          <td>{r.height}</td>
                          <td>{r.weight}</td>
                          <td>{r.bmi}</td>
                          <td>{r.fat}</td>
                          <td>
                            <button onClick={() => setEditingIndex(i)}>Edit</button>
                            <button onClick={() => deleteRecord(i)}>Delete</button>
                          </td>
                        </>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Health;
