import React, { useEffect, useState } from "react";
import Sidebar from "../../components/Sidebar/Sidebar";
import "./Todo.css";
import toastr from "toastr";
import "/node_modules/toastr/build/toastr.min.css";
import WeatherWidget from "../../components/WeatherWidget";
import Countdown from "react-countdown";
import warningAnimation from "../../assets/warning.json";
import Lottie from "lottie-react";

const trainingTypes = [
  "Running", "Swimming", "Fitness", "Yoga",
  "Boxing", "Squat", "Pull-up", "Jumping Jack", "Jump Rope"
];

const formatTime = (datetime) => {
  const date = new Date(datetime);
  return date.toLocaleString("sv-SE").replace("T", " ");
};

const Todo = () => {
  const email = localStorage.getItem("currentUser");
  if (!email) {
    window.location.href = "/";
    return null;
  }

  const [todos, setTodos] = useState([]);
  const [editIndex, setEditIndex] = useState(null);
  const [editData, setEditData] = useState({});
  const [notified, setNotified] = useState([]);

  useEffect(() => {
    const stored = JSON.parse(localStorage.getItem(`plannedTodos__${email}`) || "[]");
    setTodos(stored);
  }, []);

  const updateTodos = (updated) => {
    setTodos(updated);
    localStorage.setItem(`plannedTodos__${email}`, JSON.stringify(updated));
  };

  const handleDelete = (id) => {
    const updated = todos.filter((t) => t.id !== id);
    updateTodos(updated);
    toastr.success("Deleted");
  };

  const handleComplete = (todo) => {
    const completed = JSON.parse(localStorage.getItem(`completedTodos__${email}`) || "[]");
    completed.push(todo);
    localStorage.setItem(`completedTodos__${email}`, JSON.stringify(completed));
    handleDelete(todo.id);
    toastr.success("Marked as complete");
  };

  const handleEdit = (todo, index) => {
    setEditIndex(index);
    setEditData(todo);
  };

  const handleSaveEdit = () => {
    const updated = [...todos];
    updated[editIndex] = editData;
    updateTodos(updated);
    setEditIndex(null);
    setEditData({});
    toastr.success("Updated");
  };

  const handleTimeout = (todo) => {
    if (todo.status === "delayed") return;
    const updated = todos.map((t) =>
      t.id === todo.id ? { ...t, status: "delayed" } : t
    );
    updateTodos(updated);

    if (!notified.includes(todo.id)) {
      toastr.warning(" time to expire!", "Timeout", { timeOut: 3000 });
      setNotified((prev) => [...prev, todo.id]);
    }
  };

  const renderer = ({ hours, minutes, seconds, completed }) => {
    const totalSeconds = hours * 3600 + minutes * 60 + seconds;

    if (completed) {
      return <span style={{ color: "red" }}>Timeout</span>;
    }

    if (totalSeconds <= 60) {
      return (
        <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
          <Lottie animationData={warningAnimation} loop style={{ width: 60, height: 60 }} />
          <span style={{ color: "#ff9800", fontWeight: "bold" }}>
            {String(minutes).padStart(2, "0")}:{String(seconds).padStart(2, "0")}
          </span>
        </div>
      );
    }

    return (
      <span>
        {String(hours).padStart(2, "0")}:{String(minutes).padStart(2, "0")}:{String(seconds).padStart(2, "0")}
      </span>
    );
  };

  const sortedTodos = [...todos].sort((a, b) => {
    if ((a.status || "active") !== (b.status || "active")) {
      return (a.status || "active") === "active" ? -1 : 1;
    }
    return new Date(a.datetime) - new Date(b.datetime);
  });

  return (
    <div className="app-container">
      <Sidebar />
      <WeatherWidget />
      <div className="page-content plan-layout">
        <h2 className="center">Todo List</h2>
        <div className="todo-table-wrapper">
          <table className="todo-table">
            <thead>
              <tr>
                <th>Type</th>
                <th>Duration</th>
                <th>Weight</th>
                <th>Sets</th>
                <th>Time</th>
                <th>Countdown</th>
                <th>Status</th>
                <th>Notes</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {sortedTodos.map((todo, index) => {
                const isDelayed = todo.status === "delayed";

                return (
                  <tr key={todo.id}>
                    {editIndex === index ? (
                      <>
                        <td>
                          <select
                            value={editData.type}
                            onChange={(e) => setEditData({ ...editData, type: e.target.value })}
                          >
                            {trainingTypes.map((type) => (
                              <option key={type} value={type}>{type}</option>
                            ))}
                          </select>
                        </td>
                        <td><input value={editData.duration} onChange={(e) => setEditData({ ...editData, duration: e.target.value })} /></td>
                        <td><input value={editData.weight} onChange={(e) => setEditData({ ...editData, weight: e.target.value })} /></td>
                        <td><input value={editData.sets} onChange={(e) => setEditData({ ...editData, sets: e.target.value })} /></td>
                        <td>
                          <input
                            type="datetime-local"
                            value={editData.datetime}
                            onChange={(e) => setEditData({ ...editData, datetime: e.target.value })}
                          />
                        </td>
                        <td colSpan={4}>
                          <button className="btn green" onClick={handleSaveEdit}>Save</button>
                          <button className="btn red" onClick={() => setEditIndex(null)}>Cancel</button>
                        </td>
                      </>
                    ) : (
                      <>
                        <td>{todo.type}</td>
                        <td>{todo.duration}</td>
                        <td>{todo.weight}</td>
                        <td>{todo.sets}</td>
                        <td>{formatTime(todo.datetime)}</td>
                        <td>
                          <Countdown
                            date={new Date(todo.datetime)}
                            renderer={(props) => renderer(props)}
                            onComplete={() => handleTimeout(todo)}
                          />
                        </td>
                        <td>
                          {!todo.status && <span style={{ color: "green" }}>active</span>}
                          {todo.status === "delayed" && <span style={{ color: "orange" }}>delayed</span>}
                        </td>
                        <td>{todo.notes}</td>
                        <td>
                          {isDelayed ? (
                            <button className="btn red" onClick={() => handleDelete(todo.id)}>Delete</button>
                          ) : (
                            <>
                              <button className="btn green" onClick={() => handleEdit(todo, index)}>Edit</button>
                              <button className="btn blue" onClick={() => handleComplete(todo)}>Done</button>
                              <button className="btn red" onClick={() => handleDelete(todo.id)}>Delete</button>
                            </>
                          )}
                        </td>
                      </>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Todo;
