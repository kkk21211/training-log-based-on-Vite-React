
import React from "react";
import { Routes, Route } from "react-router-dom";

import Plan from "./pages/Plan/Plan";
import Todo from "./pages/Todo/Todo";
import Log from "./pages/Logging/Log";
import Health from "./pages/Health/Health";
import Stats from "./pages/stats/Stats";
import Diet from "./pages/diet/diet";
import Login from "./pages/Login/Login";
import Register from "./pages/Register/Register";


const App = () => {
  return (
    <Routes>
      <Route path="/" element={<Login />} />
      <Route path="/plan" element={<Plan />} />
      <Route path="/todo" element={<Todo />} />
      <Route path="/log" element={<Log />} />
      <Route path="/health" element={<Health />} />
      <Route path="/diet" element={<Diet />} />
      <Route path="/stats" element={<Stats />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
    </Routes>
  );
};

export default App;
